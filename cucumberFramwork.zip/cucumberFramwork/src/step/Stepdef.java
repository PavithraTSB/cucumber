package step;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class Stepdef {
	
	WebDriver driver;  
	
	@Given("^Launch the url \"([^\"]*)\"$")
	public void launch_the(String url) throws Throwable {
	    System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
	    driver=new ChromeDriver();
	    driver.get(url);
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    driver.manage().window().maximize();
	   driver.findElement(By.xpath("//a[text()='Login']")).click();
	    System.out.println("Login button clicked");
	    
	}

	@When("^I enter the valid (.*) and (.*)$")
	public void i_enter_the_valid_and(String Username, String Password) throws Throwable {
	    driver.findElement(By.id("inputEmail")).sendKeys(Username);
	    driver.findElement(By.id("inputPassword")).sendKeys(Password);
	    driver.findElement(By.id("login")).click();
	    
		
	}

	@Then("^user should be able login successfully$")
	public void user_should_be_able_login_successfully() throws Throwable {
	   System.out.println("Login Successfull");
	   
	}
	@Given("^Launch the webtableURL \"([^\"]*)\"$")
	public void Login(String url) {
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
	    driver=new ChromeDriver();
	    driver.get(url);
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    driver.manage().window().maximize();
	   
	}

	@When("^I fetch the datas$")
	public void fetchData()  {
	    List<WebElement>tableKey=driver.findElements(By.xpath("//table//thead//tr//th"));
	    
	    List<WebElement>tableValue=driver.findElements(By.xpath("//table[@id='example']//tbody//tr//td"));
	    LinkedHashMap<String,String>hm=new LinkedHashMap<>();
	    String key;
	    String value;
	    int count=1;
	    for(int i=0;i<tableValue.size();i++) {
	    	for(int j=0;j<tableKey.size();j++) {
	    	
	    		key=tableKey.get(j).getText();
	    		value=tableValue.get(i).getText();
	    		if(key!=null &&key.trim().length()>0) {
	    			key=key+"_"+count;
	    			hm.put(key, value);
	    			System.out.println("Key :" +key +"|" + "Value :" +value);
	    		}
	    	}
	    	count++;
	    }
	   
	}

	@Then("^user should be able to fetch data successfully$")
	public void Logout() {
	    
	    driver.quit();
	}




}
